Introduction
============


This is Zillancer Foundation App, which is used most of the projects. By using this package, you can get authentication apis, currency apis and so on.

Features
--------

* User Registration
* User type api
* Login/Logout
* Two Factor authentication using e-mail OTP
* Password change
* Password reset via e-mail
* Social Media authentication (Google/Apple)
* Currency master
* Send mail api
* Send whats app api
